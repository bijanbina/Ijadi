/* --------------------------------------- Besm Allah rahman rahim   ----------------------------------------------------
 *
 * Copyright (C) 2011 AllahSoft Std.
 *
 * Bijan Binaee <bijanbina@gmail.com>             All parts except Animation
 * Reza Faramarzi <faramarzi.reza14@gmail.com>    Anmation
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <clutter/clutter.h>
#define ROTATION_DURATION 10000
#define SIZE 400
#define DEPTH -100
#define COUNTX 1
#define COUNTY 1
#define WIDTH COUNTX*SIZE
#define HEIGHT COUNTY*SIZE
#define IMAGE_PATH "/home/bijan/C++ Project/linuxmide/Orginal/orb.png"

using namespace std;
static ClutterActor *text_actor = NULL;

int stage_button_pressed(ClutterStage *stage, ClutterEvent *event, gpointer data)
{
	cout << "Hi i'm Bijan\n";
	return 0;
}

int
main (int argc, char *argv[])
{
  ClutterActor *stage = NULL;
	GError *error;
	ClutterActor *Background = NULL;
  ClutterActor *button[COUNTX];
  error = NULL;
  ClutterGeometry geom = {0, 0, SIZE, SIZE};
  gint i = 0;
	double ColorStep[3] = {1,4,1};
	int start_color = 0;
	if ( argc == 4)
	{
		ColorStep[0] =  atof(argv[1]);
		ColorStep[1] = atof(argv[2]);
		ColorStep[2] = atof(argv[3]);
		cout << "Hi Please Enter Color Number that you want increase [0,1,2]] \n";
		cin >> start_color;
	}  
	
  if (clutter_init (&argc, &argv) != CLUTTER_INIT_SUCCESS)
    return 1;

ClutterTimeline *timeline = clutter_timeline_new (ROTATION_DURATION);
  clutter_timeline_set_loop (timeline, TRUE);	
  stage = clutter_stage_get_default ();

  clutter_actor_set_size (stage, WIDTH, HEIGHT);

	ClutterGeometry buffer_back_geom = {0 ,0, WIDTH, HEIGHT};
	Background = clutter_rectangle_new_with_color (clutter_color_new(0 , 0, 0, 255));
	clutter_actor_set_geometry (Background, &buffer_back_geom);
	//clutter_actor_set_depth (Background,2);
	clutter_actor_show (Background);
	clutter_container_add_actor (CLUTTER_CONTAINER (stage),Background);
	
	for (int j = 0; j < COUNTX;j++)
	{
			int boxCount = (WIDTH / SIZE);
			for ( i = 0 ; i < (WIDTH / SIZE) * (HEIGHT /  SIZE); i++)
			{
				ClutterColor  *buffer_Color =  clutter_color_new( (i + start_color) * ColorStep[0] , (i + start_color) * ColorStep[1], (i + start_color) * ColorStep[2], 255 );
				int k = i / (WIDTH / SIZE);
				ClutterGeometry buffer_geom = {(i % (WIDTH / SIZE)) * SIZE + (j * boxCount * SIZE) , (k) * SIZE, SIZE, SIZE};
				button[i] = clutter_texture_new_from_file (IMAGE_PATH,NULL);
				clutter_actor_set_geometry (button[i], &buffer_geom);
				clutter_actor_show (button[i]);
				clutter_container_add_actor (CLUTTER_CONTAINER (stage), button[i]);
        //clutter_actor_set_rotation (button[i],CLUTTER_X_AXIS,360,clutter_actor_get_width(button[i])/2,clutter_actor_get_height(button[i])/2,0);
        //clutter_actor_animate_with_timeline (button[i],CLUTTER_LINEAR,timeline,"rotation-angle-x",0.0,  NULL);
        clutter_actor_set_rotation (button[i],CLUTTER_Z_AXIS,360,clutter_actor_get_width(button[i])/2,clutter_actor_get_height(button[i])/2,0);
        clutter_actor_animate_with_timeline (button[i],CLUTTER_LINEAR,timeline,"rotation-angle-z",0.0,NULL);
        clutter_actor_set_z_rotation_from_gravity(button[i],0.0,CLUTTER_GRAVITY_CENTER);
			}
			ColorStep[start_color] += 1.5;
			ColorStep[0] /= 1.5;
			ColorStep[1] /= 1.5;
			ColorStep[2] /= 1.5;
	}
	text_actor = clutter_text_new_full ("Sans Bold 32px", "Bijan",clutter_color_new(255 , 255, 255, 255 ));
	clutter_container_add_actor (CLUTTER_CONTAINER (stage), text_actor);
	clutter_actor_show_all (stage);
	g_signal_connect (stage, "button-press-event", G_CALLBACK (stage_button_pressed), NULL);
	clutter_main ();

  return 0;
}






     